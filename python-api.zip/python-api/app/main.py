from fastapi import FastAPI
from pydantic import BaseModel
from typing import List

app = FastAPI(title="Python List Test")


class Item(BaseModel):
    id: int
    name: str
    price: float


items: List[Item] = []


@app.get("/")
def root():
    return {"message": "API is running"}


@app.get("/health")
def health():
    return {"status": "healthy"}


@app.get("/items")
def get_items():
    return items


@app.post("/items")
def create_item(item: Item):
    items.append(item)
    return item